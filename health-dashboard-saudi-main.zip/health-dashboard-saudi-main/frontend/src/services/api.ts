import axios, { AxiosInstance } from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authService = {
  register: (email: string, password: string, fullName: string) =>
    apiClient.post('/auth/register', { email, password, fullName }),
  login: (email: string, password: string) =>
    apiClient.post('/auth/login', { email, password }),
  logout: () => apiClient.post('/auth/logout'),
};

export const diseaseService = {
  getAllDiseases: (type?: string) =>
    apiClient.get('/diseases', { params: { type } }),
  getDiseaseById: (id: string) =>
    apiClient.get(`/diseases/${id}`),
  getPrevalenceByRegion: (province: string) =>
    apiClient.get(`/diseases/region/${province}`),
  getDiseaseStatistics: () =>
    apiClient.get('/diseases/statistics'),
};

export const vaccinationService = {
  getVaccinationData: () =>
    apiClient.get('/vaccinations'),
  getVaccinationCoverage: (province?: string) =>
    apiClient.get('/vaccinations/coverage', { params: { province } }),
  getVaccinationByRegion: (province: string) =>
    apiClient.get(`/vaccinations/region/${province}`),
};

export const facilityService = {
  getAllFacilities: (province?: string, type?: string) =>
    apiClient.get('/facilities', { params: { province, type } }),
  getFacilityById: (id: string) =>
    apiClient.get(`/facilities/${id}`),
  getFacilitiesByProvince: (province: string) =>
    apiClient.get(`/facilities/province/${province}`),
  getFacilityStatistics: () =>
    apiClient.get('/facilities/statistics'),
};

export const hajjService = {
  getHajjStatistics: (year?: number) =>
    apiClient.get('/hajj/statistics', { params: { year } }),
  getHealthAlerts: () =>
    apiClient.get('/hajj/alerts'),
  getDiseaseCases: (year?: number) =>
    apiClient.get('/hajj/disease-cases', { params: { year } }),
};

export default apiClient;
