import React, { useEffect, useState } from 'react';
import { Box, Card, CardContent, Typography, Grid, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, CircularProgress, Alert, Chip } from '@mui/material';
import { hajjService } from '../services/api';
import AssignmentIcon from '@mui/icons-material/Assignment';

interface HajjData {
  year: number;
  totalPilgrims: number;
  medicalServicesProvided: number;
  healthAlerts: Array<{
    alertType: string;
    severity: string;
    description: string;
    date: string;
  }>;
  diseasesCases: Array<{
    diseaseName: string;
    casesCount: number;
    deaths: number;
  }>;
}

const HajjMonitoring: React.FC = () => {
  const [hajjData, setHajjData] = useState<HajjData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchHajjData = async () => {
      try {
        setLoading(true);
        const response = await hajjService.getHajjStatistics();
        setHajjData(response.data.data || null);
      } catch (err: any) {
        setError(err.message || 'Failed to fetch Hajj data');
        console.error('Error fetching Hajj data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchHajjData();
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'error';
      case 'high':
        return 'warning';
      case 'medium':
        return 'info';
      case 'low':
        return 'success';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!hajjData) {
    return <Alert severity="info">No Hajj data available</Alert>;
  }

  return (
    <Box>
      <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
        <AssignmentIcon color="info" />
        Hajj Health Monitoring {hajjData.year}
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Summary Stats */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total Pilgrims
              </Typography>
              <Typography variant="h5">
                {(hajjData.totalPilgrims / 1000000).toFixed(1)}M
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Medical Services
              </Typography>
              <Typography variant="h5">
                {(hajjData.medicalServicesProvided / 1000000).toFixed(1)}M
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Active Alerts
              </Typography>
              <Typography variant="h5" color="error">
                {hajjData.healthAlerts.length}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Disease Cases
              </Typography>
              <Typography variant="h5">
                {hajjData.diseasesCases.reduce((sum, d) => sum + d.casesCount, 0)}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Health Alerts */}
      <Card sx={{ mb: 2 }}>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>
            🚨 Active Health Alerts
          </Typography>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                  <TableCell>Alert Type</TableCell>
                  <TableCell>Severity</TableCell>
                  <TableCell>Description</TableCell>
                  <TableCell>Date</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {hajjData.healthAlerts.map((alert, idx) => (
                  <TableRow key={idx}>
                    <TableCell>{alert.alertType}</TableCell>
                    <TableCell>
                      <Chip
                        label={alert.severity.toUpperCase()}
                        color={getSeverityColor(alert.severity) as any}
                        size="small"
                      />
                    </TableCell>
                    <TableCell>{alert.description}</TableCell>
                    <TableCell>{new Date(alert.date).toLocaleDateString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Disease Cases */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>
            📊 Disease Cases During Hajj
          </Typography>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                  <TableCell>Disease</TableCell>
                  <TableCell align="right">Cases</TableCell>
                  <TableCell align="right">Deaths</TableCell>
                  <TableCell align="right">Fatality Rate</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {hajjData.diseasesCases.map((disease, idx) => (
                  <TableRow key={idx}>
                    <TableCell>{disease.diseaseName}</TableCell>
                    <TableCell align="right">{disease.casesCount}</TableCell>
                    <TableCell align="right">{disease.deaths}</TableCell>
                    <TableCell align="right">
                      {((disease.deaths / disease.casesCount) * 100).toFixed(2)}%
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Box>
  );
};

export default HajjMonitoring;
