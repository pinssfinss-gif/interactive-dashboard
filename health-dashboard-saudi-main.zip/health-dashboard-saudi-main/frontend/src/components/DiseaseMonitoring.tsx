import React, { useEffect, useState } from 'react';
import { Box, Card, CardContent, Typography, Grid, List, ListItem, ListItemText, Chip, CircularProgress, Alert } from '@mui/material';
import { diseaseService } from '../services/api';
import WarningIcon from '@mui/icons-material/Warning';

interface Disease {
  _id: string;
  name: string;
  nameAr: string;
  type: string;
  prevalence: number;
  deathRate: number;
  symptoms: string[];
}

const DiseaseMonitoring: React.FC = () => {
  const [diseases, setDiseases] = useState<Disease[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDiseases = async () => {
      try {
        setLoading(true);
        const response = await diseaseService.getAllDiseases();
        setDiseases(response.data.data || []);
      } catch (err: any) {
        setError(err.message || 'Failed to fetch diseases');
        console.error('Error fetching diseases:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchDiseases();
  }, []);

  const getDiseaseColor = (type: string) => {
    switch (type) {
      case 'ncd':
        return 'warning';
      case 'communicable':
        return 'error';
      case 'emerging':
        return 'info';
      default:
        return 'default';
    }
  };

  const getDiseaseIcon = (type: string) => {
    switch (type) {
      case 'ncd':
        return '⚕️';
      case 'communicable':
        return '🦠';
      case 'emerging':
        return '⚠️';
      default:
        return '📊';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
        <WarningIcon color="warning" />
        Disease Surveillance & Monitoring
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      <Grid container spacing={2}>
        {diseases.map((disease) => (
          <Grid item xs={12} sm={6} md={4} key={disease._id}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 1 }}>
                  <Box>
                    <Typography variant="h6" sx={{ mb: 0.5 }}>
                      {getDiseaseIcon(disease.type)} {disease.name}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      {disease.nameAr}
                    </Typography>
                  </Box>
                  <Chip
                    label={disease.type.toUpperCase()}
                    color={getDiseaseColor(disease.type) as any}
                    size="small"
                  />
                </Box>

                <Box sx={{ my: 2 }}>
                  <Typography variant="body2" color="textSecondary">
                    Prevalence
                  </Typography>
                  <Typography variant="h6" color="error">
                    {disease.prevalence}%
                  </Typography>
                </Box>

                <Box sx={{ my: 2 }}>
                  <Typography variant="body2" color="textSecondary">
                    Death Rate (per 100,000)
                  </Typography>
                  <Typography variant="h6" color="error">
                    {disease.deathRate}
                  </Typography>
                </Box>

                <Typography variant="body2" sx={{ mb: 1, fontWeight: 'bold' }}>
                  Symptoms:
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {disease.symptoms.map((symptom, idx) => (
                    <Chip key={idx} label={symptom} size="small" variant="outlined" />
                  ))}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default DiseaseMonitoring;
