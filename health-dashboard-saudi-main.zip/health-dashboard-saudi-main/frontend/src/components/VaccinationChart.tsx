import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Box, Card, CardContent, Typography, CircularProgress } from '@mui/material';

interface VaccinationChartProps {
  title: string;
  data: any[];
  loading?: boolean;
}

const VaccinationChart: React.FC<VaccinationChartProps> = ({ title, data, loading = false }) => {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6" sx={{ mb: 2 }}>
          {title}
        </Typography>
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 5 }}>
            <CircularProgress />
          </Box>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="vaccineName" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="coveragePercentage" fill="#8884d8" name="Coverage %" />
            </BarChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
};

export default VaccinationChart;
