import React, { useEffect, useState } from 'react';
import { Box, Card, CardContent, Typography, Grid, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, CircularProgress, Alert, Chip } from '@mui/material';
import { facilityService } from '../services/api';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';

interface Facility {
  _id: string;
  name: string;
  nameAr: string;
  type: string;
  province: string;
  capacity: {
    beds: number;
    doctors: number;
    nurses: number;
  };
  services: string[];
  telemedicineEnabled: boolean;
}

const HealthFacilities: React.FC = () => {
  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchFacilities = async () => {
      try {
        setLoading(true);
        const response = await facilityService.getAllFacilities();
        setFacilities(response.data.data || []);
      } catch (err: any) {
        setError(err.message || 'Failed to fetch facilities');
        console.error('Error fetching facilities:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchFacilities();
  }, []);

  const getFacilityTypeIcon = (type: string) => {
    switch (type) {
      case 'hospital':
        return '🏥';
      case 'clinic':
        return '🏨';
      case 'health_center':
        return '🏛️';
      default:
        return '🏗️';
    }
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  const hospitalCount = facilities.filter((f) => f.type === 'hospital').length;
  const clinicCount = facilities.filter((f) => f.type === 'clinic').length;
  const totalBeds = facilities.reduce((sum, f) => sum + f.capacity.beds, 0);
  const totalDoctors = facilities.reduce((sum, f) => sum + f.capacity.doctors, 0);

  return (
    <Box>
      <Typography variant="h6" sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1 }}>
        <LocalHospitalIcon color="success" />
        Health Facilities Network
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Summary Stats */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Hospitals
              </Typography>
              <Typography variant="h5">{hospitalCount}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Clinics
              </Typography>
              <Typography variant="h5">{clinicCount}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Total Beds
              </Typography>
              <Typography variant="h5">{totalBeds}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography color="textSecondary" gutterBottom>
                Doctors
              </Typography>
              <Typography variant="h5">{totalDoctors}</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Facilities Table */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>
            📍 Healthcare Facilities
          </Typography>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                  <TableCell>Facility Name</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Province</TableCell>
                  <TableCell align="right">Beds</TableCell>
                  <TableCell align="right">Doctors</TableCell>
                  <TableCell align="right">Nurses</TableCell>
                  <TableCell>Telemedicine</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {facilities.map((facility) => (
                  <TableRow key={facility._id} hover>
                    <TableCell>
                      {getFacilityTypeIcon(facility.type)} {facility.name}
                    </TableCell>
                    <TableCell>
                      <Chip label={facility.type.toUpperCase()} size="small" />
                    </TableCell>
                    <TableCell>{facility.province}</TableCell>
                    <TableCell align="right">{facility.capacity.beds}</TableCell>
                    <TableCell align="right">{facility.capacity.doctors}</TableCell>
                    <TableCell align="right">{facility.capacity.nurses}</TableCell>
                    <TableCell>
                      {facility.telemedicineEnabled ? (
                        <Chip label="Enabled" color="success" size="small" />
                      ) : (
                        <Chip label="Disabled" size="small" />
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Box>
  );
};

export default HealthFacilities;
