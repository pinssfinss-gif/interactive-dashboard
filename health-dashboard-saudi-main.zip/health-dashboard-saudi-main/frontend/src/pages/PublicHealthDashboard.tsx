import React, { useEffect, useState } from 'react';
import { Box, Grid, Card, CardContent, Typography, CircularProgress, Alert } from '@mui/material';
import KPIDashboard from '../components/KPIDashboard';
import DiseaseChart from '../components/DiseaseChart';
import VaccinationChart from '../components/VaccinationChart';
import { diseaseService, vaccinationService, hajjService } from '../services/api';
import { mockDashboardKPIs, mockDiseases, mockVaccinations } from '../../data/mockData';

const PublicHealthDashboard: React.FC = () => {
  const [kpis, setKpis] = useState(mockDashboardKPIs);
  const [diseases, setDiseases] = useState(mockDiseases);
  const [vaccinations, setVaccinations] = useState(mockVaccinations);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Fetch data from API
        const [diseaseRes, vaccinationRes] = await Promise.all([
          diseaseService.getAllDiseases(),
          vaccinationService.getVaccinationData(),
        ]);

        if (diseaseRes.data.data) {
          setDiseases(diseaseRes.data.data);
        }
        if (vaccinationRes.data.data) {
          setVaccinations(vaccinationRes.data.data);
        }
      } catch (err: any) {
        console.error('Error fetching data:', err);
        setError(err.message || 'Failed to fetch data');
        // Keep mock data on error
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  const diseaseChartData = [
    { name: 'Diabetes', ncd: 17.7, communicable: 0.5, emerging: 0.1 },
    { name: 'Hypertension', ncd: 25, communicable: 1, emerging: 0.2 },
    { name: 'Obesity', ncd: 28.7, communicable: 0.3, emerging: 0.05 },
  ];

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 3, fontWeight: 'bold' }}>
        📊 Public Health Officer Dashboard
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* KPI Cards */}
      <KPIDashboard kpis={kpis} />

      {/* Charts */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} md={6}>
          <DiseaseChart
            title="Disease Prevalence Trends"
            data={diseaseChartData}
            dataKeys={[
              { key: 'ncd', stroke: '#8884d8', name: 'Non-Communicable' },
              { key: 'communicable', stroke: '#82ca9d', name: 'Communicable' },
              { key: 'emerging', stroke: '#ffc658', name: 'Emerging' },
            ]}
            loading={loading}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <VaccinationChart title="Vaccination Coverage" data={vaccinations} loading={loading} />
        </Grid>
      </Grid>

      {/* Disease List */}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>
            Disease Surveillance
          </Typography>
          <Grid container spacing={2}>
            {diseases.slice(0, 6).map((disease, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography color="textSecondary" gutterBottom>
                      {disease.name}
                    </Typography>
                    <Typography variant="h6">
                      {disease.prevalence}%
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      Type: {disease.type}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
};

export default PublicHealthDashboard;
