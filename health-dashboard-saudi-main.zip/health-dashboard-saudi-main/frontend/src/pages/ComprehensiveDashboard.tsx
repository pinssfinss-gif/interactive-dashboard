import React from 'react';
import { Box, Grid, Tab, Tabs } from '@mui/material';
import { useState } from 'react';
import KPIDashboard from '../components/KPIDashboard';
import DiseaseMonitoring from '../components/DiseaseMonitoring';
import VaccinationChart from '../components/VaccinationChart';
import HealthFacilities from '../components/HealthFacilities';
import HajjMonitoring from '../components/HajjMonitoring';
import { mockDashboardKPIs, mockVaccinations } from '../../data/mockData';
import Typography from '@mui/material/Typography';

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ py: 2 }}>{children}</Box>}
    </div>
  );
}

const ComprehensiveDashboard: React.FC = () => {
  const [tabValue, setTabValue] = useState(0);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Box>
      <Typography variant="h4" sx={{ mb: 3, fontWeight: 'bold' }}>
        📊 Comprehensive Health Dashboard
      </Typography>

      {/* KPI Dashboard */}
      <Box sx={{ mb: 3 }}>
        <KPIDashboard kpis={mockDashboardKPIs} />
      </Box>

      {/* Tabs for different sections */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        <Tabs value={tabValue} onChange={handleTabChange} aria-label="dashboard tabs">
          <Tab label="🦠 Disease Monitoring" id="tab-0" aria-controls="tabpanel-0" />
          <Tab label="💉 Vaccination" id="tab-1" aria-controls="tabpanel-1" />
          <Tab label="🏥 Facilities" id="tab-2" aria-controls="tabpanel-2" />
          <Tab label="🕌 Hajj Monitoring" id="tab-3" aria-controls="tabpanel-3" />
        </Tabs>
      </Box>

      {/* Disease Monitoring Tab */}
      <TabPanel value={tabValue} index={0}>
        <DiseaseMonitoring />
      </TabPanel>

      {/* Vaccination Tab */}
      <TabPanel value={tabValue} index={1}>
        <VaccinationChart title="Vaccination Coverage by Program" data={mockVaccinations} />
      </TabPanel>

      {/* Facilities Tab */}
      <TabPanel value={tabValue} index={2}>
        <HealthFacilities />
      </TabPanel>

      {/* Hajj Monitoring Tab */}
      <TabPanel value={tabValue} index={3}>
        <HajjMonitoring />
      </TabPanel>
    </Box>
  );
};

export default ComprehensiveDashboard;
