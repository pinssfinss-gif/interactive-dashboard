import React, { useState } from 'react';
import { Box, Container, Card, CardContent, TextField, Button, Typography, Alert, CircularProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { authService } from '../services/api';
import { UserRole } from '../../backend/src/models/User';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError(null);
      const response = await authService.login(email, password);
      const { token, user } = response.data;
      login(token, user);
      navigate('/');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = (demoRole: string) => {
    const demoUsers: { [key: string]: { email: string; password: string; fullName: string } } = {
      officer: { email: 'officer@health.gov.sa', password: 'Officer123!', fullName: 'Dr. Ahmed' },
      manager: { email: 'manager@hospital.sa', password: 'Manager123!', fullName: 'Mr. Khalid' },
      patient: { email: 'patient@email.sa', password: 'Patient123!', fullName: 'Ms. Fatima' },
    };
    const user = demoUsers[demoRole];
    if (user) {
      setEmail(user.email);
      setPassword(user.password);
    }
  };

  return (
    <Container maxWidth="sm" sx={{ py: 10 }}>
      <Card>
        <CardContent sx={{ p: 4 }}>
          <Typography variant="h4" sx={{ mb: 1, textAlign: 'center', fontWeight: 'bold' }}>
            🏥 Health Dashboard
          </Typography>
          <Typography variant="subtitle1" sx={{ mb: 3, textAlign: 'center', color: 'textSecondary' }}>
            Saudi Arabia
          </Typography>

          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

          <Box component="form" onSubmit={handleLogin}>
            <TextField
              fullWidth
              label="Email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              margin="normal"
              required
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'Login'}
            </Button>
          </Box>

          <Typography variant="subtitle2" sx={{ mt: 3, mb: 2, textAlign: 'center' }}>
            Demo Users
          </Typography>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button
              size="small"
              variant="outlined"
              onClick={() => handleDemoLogin('officer')}
              fullWidth
            >
              Officer
            </Button>
            <Button
              size="small"
              variant="outlined"
              onClick={() => handleDemoLogin('manager')}
              fullWidth
            >
              Manager
            </Button>
            <Button
              size="small"
              variant="outlined"
              onClick={() => handleDemoLogin('patient')}
              fullWidth
            >
              Patient
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Container>
  );
};

export default LoginPage;
