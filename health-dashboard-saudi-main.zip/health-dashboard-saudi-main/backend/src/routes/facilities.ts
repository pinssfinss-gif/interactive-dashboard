import { Router } from 'express';
import { facilityController } from '../controllers/facilityController';
import { authMiddleware } from '../middleware/auth';

const router = Router();

router.get('/', authMiddleware, facilityController.getAllFacilities);
router.get('/statistics', authMiddleware, facilityController.getFacilityStatistics);
router.get('/:id', authMiddleware, facilityController.getFacilityById);
router.get('/province/:province', authMiddleware, facilityController.getFacilitiesByProvince);

export default router;
