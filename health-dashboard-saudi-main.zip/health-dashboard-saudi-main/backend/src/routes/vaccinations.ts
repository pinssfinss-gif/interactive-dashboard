import { Router } from 'express';
import { vaccinationController } from '../controllers/vaccinationController';
import { authMiddleware } from '../middleware/auth';

const router = Router();

router.get('/', authMiddleware, vaccinationController.getVaccinationData);
router.get('/coverage', authMiddleware, vaccinationController.getVaccinationCoverage);
router.get('/region/:province', authMiddleware, vaccinationController.getVaccinationByRegion);

export default router;
