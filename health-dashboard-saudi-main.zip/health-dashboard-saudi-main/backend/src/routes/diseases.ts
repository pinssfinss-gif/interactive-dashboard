import { Router } from 'express';
import { diseaseController } from '../controllers/diseaseController';
import { authMiddleware } from '../middleware/auth';

const router = Router();

router.get('/', authMiddleware, diseaseController.getAllDiseases);
router.get('/statistics', authMiddleware, diseaseController.getDiseaseStatistics);
router.get('/:id', authMiddleware, diseaseController.getDiseaseById);
router.get('/region/:province', authMiddleware, diseaseController.getPrevalenceByRegion);

export default router;
