import { Router } from 'express';
import { hajjController } from '../controllers/hajjController';
import { authMiddleware } from '../middleware/auth';

const router = Router();

router.get('/statistics', authMiddleware, hajjController.getHajjStatistics);
router.get('/alerts', authMiddleware, hajjController.getHealthAlerts);
router.get('/disease-cases', authMiddleware, hajjController.getDiseaseCases);

export default router;
