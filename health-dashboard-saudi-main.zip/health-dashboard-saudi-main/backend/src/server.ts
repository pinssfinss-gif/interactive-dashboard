import express, { Express } from 'express';
import cors from 'cors';
import { connectDB } from './database/mongoose';
import { config } from './config/environment';
import { errorHandler } from './middleware/errorHandler';

// Routes
import authRoutes from './routes/auth';
import diseaseRoutes from './routes/diseases';
import vaccinationRoutes from './routes/vaccinations';
import facilityRoutes from './routes/facilities';
import hajjRoutes from './routes/hajj';

const app: Express = express();

// Middleware
app.use(cors({ origin: config.corsOrigin }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Connect to database
connectDB();

// Health check
app.get('/health', (req, res) => {
  res.json({ status: '✅ Server is running', timestamp: new Date() });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/diseases', diseaseRoutes);
app.use('/api/vaccinations', vaccinationRoutes);
app.use('/api/facilities', facilityRoutes);
app.use('/api/hajj', hajjRoutes);

// Error handler
app.use(errorHandler);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

const PORT = config.port;

app.listen(PORT, () => {
  console.log(`\n🏥 Health Dashboard API Server`);
  console.log(`📍 Running on: http://localhost:${PORT}`);
  console.log(`📝 Environment: ${config.nodeEnv}`);
  console.log(`🗄️  Database: ${config.mongoUri}`);
  console.log('\n✅ Server ready to accept connections\n');
});

export default app;
