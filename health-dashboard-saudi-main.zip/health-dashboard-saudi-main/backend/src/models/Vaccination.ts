import mongoose, { Schema, Document } from 'mongoose';

export interface IVaccination extends Document {
  vaccineName: string;
  vaccineNameAr: string;
  targetDisease: string;
  coveragePercentage: number;
  totalDose: number;
  province: string;
  population: number;
  lastUpdated: Date;
  notes: string;
}

const vaccinationSchema = new Schema<IVaccination>(
  {
    vaccineName: { type: String, required: true },
    vaccineNameAr: { type: String, required: true },
    targetDisease: { type: String, required: true },
    coveragePercentage: { type: Number, required: true },
    totalDose: { type: Number, required: true },
    province: { type: String, required: true },
    population: { type: Number, required: true },
    lastUpdated: { type: Date, default: Date.now },
    notes: String,
  },
  { timestamps: true }
);

export default mongoose.model<IVaccination>('Vaccination', vaccinationSchema);
