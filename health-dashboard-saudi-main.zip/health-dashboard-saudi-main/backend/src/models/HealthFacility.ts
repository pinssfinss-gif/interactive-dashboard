import mongoose, { Schema, Document } from 'mongoose';

export interface IHealthFacility extends Document {
  name: string;
  nameAr: string;
  type: 'hospital' | 'clinic' | 'health_center';
  province: string;
  region: string;
  coordinates: {
    latitude: number;
    longitude: number;
  };
  capacity: {
    beds: number;
    doctors: number;
    nurses: number;
    otherStaff: number;
  };
  services: string[];
  telemedicineEnabled: boolean;
  contactNumber: string;
}

const healthFacilitySchema = new Schema<IHealthFacility>(
  {
    name: { type: String, required: true },
    nameAr: { type: String, required: true },
    type: { type: String, enum: ['hospital', 'clinic', 'health_center'], required: true },
    province: { type: String, required: true },
    region: String,
    coordinates: {
      latitude: Number,
      longitude: Number,
    },
    capacity: {
      beds: { type: Number, default: 0 },
      doctors: { type: Number, default: 0 },
      nurses: { type: Number, default: 0 },
      otherStaff: { type: Number, default: 0 },
    },
    services: [String],
    telemedicineEnabled: { type: Boolean, default: false },
    contactNumber: String,
  },
  { timestamps: true }
);

export default mongoose.model<IHealthFacility>('HealthFacility', healthFacilitySchema);
