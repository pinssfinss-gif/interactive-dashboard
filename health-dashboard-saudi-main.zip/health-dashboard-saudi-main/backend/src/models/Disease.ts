import mongoose, { Schema, Document } from 'mongoose';

export interface IDisease extends Document {
  name: string;
  nameAr: string; // Arabic name
  type: 'ncd' | 'communicable' | 'emerging'; // Non-communicable, Communicable, Emerging
  prevalence: number; // Percentage
  prevalenceUnit: string; // e.g., '%', 'per 100,000'
  deathRate: number; // Deaths per 100,000
  targetPopulation: string; // e.g., 'adults 20-79 years'
  region: string[]; // Array of provinces
  lastUpdated: Date;
  description: string;
  preventionMethods: string[];
  symptoms: string[];
}

const diseaseSchema = new Schema<IDisease>(
  {
    name: { type: String, required: true },
    nameAr: { type: String, required: true },
    type: { type: String, enum: ['ncd', 'communicable', 'emerging'], required: true },
    prevalence: { type: Number, required: true },
    prevalenceUnit: { type: String, default: '%' },
    deathRate: { type: Number, default: 0 },
    targetPopulation: { type: String },
    region: [String],
    lastUpdated: { type: Date, default: Date.now },
    description: String,
    preventionMethods: [String],
    symptoms: [String],
  },
  { timestamps: true }
);

export default mongoose.model<IDisease>('Disease', diseaseSchema);
