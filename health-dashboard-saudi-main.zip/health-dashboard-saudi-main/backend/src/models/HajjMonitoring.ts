import mongoose, { Schema, Document } from 'mongoose';

export interface IHajjMonitoring extends Document {
  year: number;
  totalPilgrims: number;
  medicalServicesProvided: number;
  healthAlerts: Array<{
    alertType: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
    description: string;
    date: Date;
  }>;
  diseasesCases: Array<{
    diseaseName: string;
    casesCount: number;
    deaths: number;
  }>;
  vaccinationRequired: string[];
  lastUpdated: Date;
}

const hajjMonitoringSchema = new Schema<IHajjMonitoring>(
  {
    year: { type: Number, required: true },
    totalPilgrims: { type: Number, required: true },
    medicalServicesProvided: { type: Number, required: true },
    healthAlerts: [
      {
        alertType: String,
        severity: { type: String, enum: ['low', 'medium', 'high', 'critical'] },
        description: String,
        date: Date,
      },
    ],
    diseasesCases: [
      {
        diseaseName: String,
        casesCount: Number,
        deaths: Number,
      },
    ],
    vaccinationRequired: [String],
    lastUpdated: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export default mongoose.model<IHajjMonitoring>('HajjMonitoring', hajjMonitoringSchema);
