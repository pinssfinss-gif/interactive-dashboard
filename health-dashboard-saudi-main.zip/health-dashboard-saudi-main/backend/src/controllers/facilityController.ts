import { Response } from 'express';
import HealthFacility from '../models/HealthFacility';
import { AuthenticatedRequest } from '../middleware/auth';

export const facilityController = {
  getAllFacilities: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { province, type } = req.query;

      const filter: any = {};
      if (province) filter.province = province;
      if (type) filter.type = type;

      const facilities = await HealthFacility.find(filter);

      res.json({
        success: true,
        count: facilities.length,
        data: facilities,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch facilities', error });
    }
  },

  getFacilityById: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const facility = await HealthFacility.findById(id);

      if (!facility) {
        return res.status(404).json({ message: 'Facility not found' });
      }

      res.json({
        success: true,
        data: facility,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch facility', error });
    }
  },

  getFacilitiesByProvince: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { province } = req.params;
      const facilities = await HealthFacility.find({ province });

      res.json({
        success: true,
        province,
        count: facilities.length,
        data: facilities,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch provincial facilities', error });
    }
  },

  getFacilityStatistics: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const stats = await HealthFacility.aggregate([
        {
          $group: {
            _id: '$type',
            count: { $sum: 1 },
            totalBeds: { $sum: '$capacity.beds' },
            totalDoctors: { $sum: '$capacity.doctors' },
            totalNurses: { $sum: '$capacity.nurses' },
          },
        },
      ]);

      res.json({
        success: true,
        data: stats,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch facility statistics', error });
    }
  },
};
