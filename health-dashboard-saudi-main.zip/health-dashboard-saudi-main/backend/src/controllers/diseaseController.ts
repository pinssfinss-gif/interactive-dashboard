import { Response } from 'express';
import Disease from '../models/Disease';
import { AuthenticatedRequest } from '../middleware/auth';

export const diseaseController = {
  getAllDiseases: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { type } = req.query;

      const filter = type ? { type } : {};
      const diseases = await Disease.find(filter);

      res.json({
        success: true,
        count: diseases.length,
        data: diseases,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch diseases', error });
    }
  },

  getDiseaseById: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const disease = await Disease.findById(id);

      if (!disease) {
        return res.status(404).json({ message: 'Disease not found' });
      }

      res.json({
        success: true,
        data: disease,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch disease', error });
    }
  },

  getPrevalenceByRegion: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { province } = req.params;

      const diseases = await Disease.find({ region: province });

      res.json({
        success: true,
        province,
        count: diseases.length,
        data: diseases,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch regional data', error });
    }
  },

  getDiseaseStatistics: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const stats = await Disease.aggregate([
        {
          $group: {
            _id: '$type',
            count: { $sum: 1 },
            avgPrevalence: { $avg: '$prevalence' },
            maxPrevalence: { $max: '$prevalence' },
          },
        },
      ]);

      res.json({
        success: true,
        data: stats,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch statistics', error });
    }
  },
};
