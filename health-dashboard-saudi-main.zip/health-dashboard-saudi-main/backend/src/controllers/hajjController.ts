import { Response } from 'express';
import HajjMonitoring from '../models/HajjMonitoring';
import { AuthenticatedRequest } from '../middleware/auth';

export const hajjController = {
  getHajjStatistics: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { year } = req.query;

      const filter = year ? { year: parseInt(year as string) } : {};
      const hajjData = await HajjMonitoring.findOne(filter).sort({ year: -1 });

      if (!hajjData) {
        return res.status(404).json({ message: 'Hajj data not found' });
      }

      res.json({
        success: true,
        data: hajjData,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch Hajj statistics', error });
    }
  },

  getHealthAlerts: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const hajjData = await HajjMonitoring.findOne().sort({ year: -1 });

      if (!hajjData) {
        return res.status(404).json({ message: 'Hajj data not found' });
      }

      res.json({
        success: true,
        alerts: hajjData.healthAlerts,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch health alerts', error });
    }
  },

  getDiseaseCases: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { year } = req.query;

      const filter = year ? { year: parseInt(year as string) } : {};
      const hajjData = await HajjMonitoring.findOne(filter).sort({ year: -1 });

      if (!hajjData) {
        return res.status(404).json({ message: 'Hajj data not found' });
      }

      res.json({
        success: true,
        diseaseCases: hajjData.diseasesCases,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch disease cases', error });
    }
  },
};
