import { Response } from 'express';
import Vaccination from '../models/Vaccination';
import { AuthenticatedRequest } from '../middleware/auth';

export const vaccinationController = {
  getVaccinationData: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const vaccinations = await Vaccination.find();

      res.json({
        success: true,
        count: vaccinations.length,
        data: vaccinations,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch vaccination data', error });
    }
  },

  getVaccinationCoverage: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { province } = req.query;

      const filter = province ? { province } : {};
      const vaccinations = await Vaccination.find(filter);

      const coverage = vaccinations.map((v) => ({
        vaccine: v.vaccineName,
        coverage: v.coveragePercentage,
        province: v.province,
      }));

      res.json({
        success: true,
        data: coverage,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch vaccination coverage', error });
    }
  },

  getVaccinationByRegion: async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { province } = req.params;

      const vaccinations = await Vaccination.find({ province });

      res.json({
        success: true,
        province,
        count: vaccinations.length,
        data: vaccinations,
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch regional vaccination data', error });
    }
  },
};
