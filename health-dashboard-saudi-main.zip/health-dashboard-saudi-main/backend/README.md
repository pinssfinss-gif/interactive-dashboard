# Health Dashboard Saudi Arabia - Backend Setup

## Installation

```bash
cd backend
npm install
```

## Environment Setup

Create a `.env` file:

```env
PORT=5000
NODE_ENV=development
MONGO_URI=mongodb://localhost:27017/health-dashboard
JWT_SECRET=your_jwt_secret_key_here
JWT_EXPIRE=7d
CORS_ORIGIN=http://localhost:3000
```

## Running Development Server

```bash
npm run dev
```

Server will be available at `http://localhost:5000`

## API Documentation

### Health Check
- `GET /health` - Server health status

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout

### Diseases
- `GET /api/diseases` - Get all diseases
- `GET /api/diseases/:id` - Get disease details
- `GET /api/diseases/region/:province` - Get diseases by region
- `GET /api/diseases/statistics` - Get disease statistics

### Vaccinations
- `GET /api/vaccinations` - Get all vaccination data
- `GET /api/vaccinations/coverage` - Get vaccination coverage
- `GET /api/vaccinations/region/:province` - Get regional vaccination data

### Facilities
- `GET /api/facilities` - Get all health facilities
- `GET /api/facilities/:id` - Get facility details
- `GET /api/facilities/province/:province` - Get facilities by province
- `GET /api/facilities/statistics` - Get facility statistics

### Hajj
- `GET /api/hajj/statistics` - Get Hajj statistics
- `GET /api/hajj/alerts` - Get health alerts
- `GET /api/hajj/disease-cases` - Get disease cases

## Database

MongoDB connection required. Configure `MONGO_URI` in `.env`

Default collections:
- `users` - User accounts and authentication
- `diseases` - Disease surveillance data
- `vaccinations` - Vaccination program data
- `healthfacilities` - Healthcare facility information
- `hajjmonitorings` - Hajj health monitoring data

## Project Structure

```
src/
├── config/
│   └── environment.ts        # Environment variables
├── database/
│   └── mongoose.ts           # MongoDB connection
├── models/
│   ├── User.ts               # User schema and model
│   ├── Disease.ts            # Disease schema
│   ├── Vaccination.ts        # Vaccination schema
│   ├── HealthFacility.ts     # Facility schema
│   └── HajjMonitoring.ts     # Hajj monitoring schema
├── controllers/
│   ├── authController.ts     # Authentication logic
│   ├���─ diseaseController.ts  # Disease endpoints
│   ├── vaccinationController.ts
│   ├── facilityController.ts
│   └── hajjController.ts
├── middleware/
│   ├── auth.ts               # JWT authentication
│   └── errorHandler.ts       # Error handling
├── routes/
│   ├── auth.ts
│   ├── diseases.ts
│   ├── vaccinations.ts
│   ├── facilities.ts
│   └── hajj.ts
└── server.ts                 # Application entry point
```

## Authentication

API uses JWT-based authentication. Include token in Authorization header:

```
Authorization: Bearer <your_jwt_token>
```

## User Roles

- `public_health_officer` - Access to public health dashboards
- `facility_manager` - Manage health facilities
- `patient` - Personal health records
- `admin` - Full system access

## Error Handling

All errors are handled with appropriate HTTP status codes and JSON responses.
